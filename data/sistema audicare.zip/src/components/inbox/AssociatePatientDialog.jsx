import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { getPatients } from '@/database';
import { useToast } from '@/components/ui/use-toast';
import { Search } from 'lucide-react';

const AssociatePatientDialog = ({ open, onOpenChange, onAssociate }) => {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatientId, setSelectedPatientId] = useState(null);
  const { toast } = useToast();

  const loadPatients = useCallback(async () => {
    try {
      setLoading(true);
      const data = await getPatients();
      setPatients(data);
    } catch (error) {
      toast({
        title: "Erro ao carregar pacientes",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    if (open) {
      loadPatients();
    }
  }, [open, loadPatients]);

  const filteredPatients = patients.filter(patient =>
    patient.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.cpf?.includes(searchTerm)
  );

  const handleConfirm = () => {
    if (!selectedPatientId) {
      toast({
        title: "Nenhum paciente selecionado",
        description: "Por favor, selecione um paciente da lista.",
        variant: "destructive",
      });
      return;
    }
    onAssociate(selectedPatientId);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Associar Contato a Paciente</DialogTitle>
          <DialogDescription>
            Busque e selecione um paciente existente para vincular a este contato.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome ou CPF..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <ScrollArea className="h-72 w-full rounded-md border">
            <div className="p-4">
              {loading ? (
                <p>Carregando pacientes...</p>
              ) : filteredPatients.length > 0 ? (
                filteredPatients.map((patient) => (
                  <div
                    key={patient.id}
                    className={`p-2 rounded-md cursor-pointer hover:bg-secondary ${selectedPatientId === patient.id ? 'bg-secondary font-semibold' : ''}`}
                    onClick={() => setSelectedPatientId(patient.id)}
                  >
                    <p>{patient.name}</p>
                    <p className="text-sm text-muted-foreground">{patient.cpf}</p>
                  </div>
                ))
              ) : (
                <p className="text-center text-muted-foreground">Nenhum paciente encontrado.</p>
              )}
            </div>
          </ScrollArea>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleConfirm} disabled={!selectedPatientId}>Confirmar Associação</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AssociatePatientDialog;