import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tag, Calendar, Mail, Phone, PlusCircle, MessageSquare as MessageSquareText, User, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

const RightPanel = ({ conversation, onClose }) => {
    const { toast } = useToast();

    if (!conversation || !conversation.contact) {
        return (
            <aside className="w-full lg:w-96 border-l bg-card flex-shrink-0 p-6 flex items-center justify-center text-center text-muted-foreground">
                <p>Selecione uma conversa para ver os detalhes do contato.</p>
            </aside>
        );
    }

    const showToast = () => {
        toast({
            title: "🚧 Funcionalidade em breve!",
            description: "Você poderá executar esta ação em futuras atualizações. 🚀",
        });
    };

    const contact = conversation.contact;
    const contactName = contact.name || contact.phone || 'Desconhecido';

    return (
        <aside className="w-full lg:w-96 border-l bg-card flex-shrink-0 flex flex-col h-full">
            <div className="p-4 border-b flex items-center justify-between">
                <h2 className="text-lg font-semibold">Detalhes do Contato</h2>
                <Button variant="ghost" size="icon" onClick={onClose} className="lg:hidden">
                    <X className="h-5 w-5" />
                </Button>
            </div>

            <ScrollArea className="flex-1">
                <div className="p-6 text-center border-b">
                    <Avatar className="h-20 w-20 mx-auto">
                        <AvatarImage src={contact.avatar_url} alt={contactName} />
                        <AvatarFallback className="text-3xl">{contactName.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <h3 className="mt-4 text-xl font-semibold">{contactName}</h3>
                    <div className="flex items-center justify-center gap-2 mt-2 text-sm text-muted-foreground">
                        <Tag className="h-4 w-4" />
                        <span>{contact.status || 'Lead'}</span>
                    </div>
                </div>

                <div className="p-6 space-y-4">
                    <div className="space-y-2">
                        <h4 className="font-semibold text-sm text-muted-foreground">Informações</h4>
                        <div className="flex items-center gap-3">
                            <Phone className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{contact.phone || 'Não informado'}</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <Mail className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{contact.email || 'Não informado'}</span>
                        </div>
                    </div>

                    <Separator />

                    <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">Ações Rápidas</h4>
                        <div className="grid grid-cols-2 gap-2">
                            <Button variant="outline" size="sm" onClick={showToast}>
                                <PlusCircle className="h-4 w-4 mr-2" />
                                Agendar
                            </Button>
                            <Button variant="outline" size="sm" onClick={showToast}>
                                <MessageSquareText className="h-4 w-4 mr-2" />
                                Template
                            </Button>
                             <Button variant="outline" size="sm" className="col-span-2" onClick={showToast}>
                                <User className="h-4 w-4 mr-2" />
                                Ver Perfil do Paciente
                            </Button>
                        </div>
                    </div>
                    
                    <Separator />

                    <Card>
                        <CardHeader className="p-4">
                            <CardTitle className="text-base flex items-center gap-2">
                                <Calendar className="h-5 w-5" />
                                Histórico de Agendamentos
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 pt-0 text-center text-sm text-muted-foreground">
                            <p>Nenhum agendamento encontrado.</p>
                            <Button variant="link" size="sm" onClick={showToast}>Criar novo agendamento</Button>
                        </CardContent>
                    </Card>
                </div>
            </ScrollArea>
        </aside>
    );
};

export default RightPanel;