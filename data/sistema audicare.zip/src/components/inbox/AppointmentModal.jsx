import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

const AppointmentModal = ({ isOpen, onClose, onCreateAppointment, patientName }) => {
  const { toast } = useToast();
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [professional, setProfessional] = useState('');
  const [consultationType, setConsultationType] = useState('');
  const [errors, setErrors] = useState({});

  const professionals = ['Dr. João Silva', 'Dra. Maria Oliveira', 'Dr. Pedro Martins'];
  const consultationTypes = ['Primeira Consulta', 'Retorno', 'Exame Auditivo', 'Ajuste de Aparelho'];

  const validate = () => {
    const newErrors = {};
    if (!date) newErrors.date = 'Data é obrigatória.';
    if (!time) newErrors.time = 'Hora é obrigatória.';
    if (!professional) newErrors.professional = 'Profissional é obrigatório.';
    if (!consultationType) newErrors.consultationType = 'Tipo de consulta é obrigatório.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) {
      onCreateAppointment({
        date,
        time,
        professional,
        consultationType,
        patientName,
      });
    } else {
      toast({
        variant: 'destructive',
        title: 'Campos inválidos',
        description: 'Por favor, preencha todos os campos obrigatórios.',
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Criar Agendamento</DialogTitle>
          <DialogDescription>
            Agende uma nova consulta para {patientName}.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="date" className="text-right">
              Data
            </Label>
            <div className="col-span-3">
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={errors.date ? 'border-destructive' : ''}
              />
              {errors.date && <p className="text-xs text-destructive mt-1">{errors.date}</p>}
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="time" className="text-right">
              Hora
            </Label>
            <div className="col-span-3">
              <Input
                id="time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className={errors.time ? 'border-destructive' : ''}
              />
              {errors.time && <p className="text-xs text-destructive mt-1">{errors.time}</p>}
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="professional" className="text-right">
              Profissional
            </Label>
            <div className="col-span-3">
              <Select value={professional} onValueChange={setProfessional}>
                <SelectTrigger className={errors.professional ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Selecione..." />
                </SelectTrigger>
                <SelectContent>
                  {professionals.map((prof) => (
                    <SelectItem key={prof} value={prof}>{prof}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.professional && <p className="text-xs text-destructive mt-1">{errors.professional}</p>}
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="consultationType" className="text-right">
              Tipo
            </Label>
            <div className="col-span-3">
              <Select value={consultationType} onValueChange={setConsultationType}>
                <SelectTrigger className={errors.consultationType ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Selecione..." />
                </SelectTrigger>
                <SelectContent>
                  {consultationTypes.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.consultationType && <p className="text-xs text-destructive mt-1">{errors.consultationType}</p>}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
          <Button type="submit" onClick={handleSubmit}>Agendar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AppointmentModal;