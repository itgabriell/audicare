# AudiCare - Exemplos Visuais do Design System

Este documento apresenta exemplos de como os componentes e estilos do Design System AudiCare são aplicados na prática, com foco no tema escuro.

## 1. Botões

Os botões são elementos interativos essenciais.