# Queries SQL para Testes

Este arquivo contém um conjunto de queries SQL úteis para popular o banco de dados com dados de teste e para verificar a funcionalidade do sistema durante o desenvolvimento.

**Atenção:** Execute estas queries no **SQL Editor** do seu projeto Supabase. Substitua os valores de UUIDs e outros dados conforme necessário.

## 1. Inserir Dados de Teste

Estas queries assumem que você já tem uma clínica e um usuário (perfil) criados.